# Little Rascal — Editorial reflection script

Planned total 9:47; 1032 English words; includes 120-second edited demo.

## 01 — Little Rascal

Duration: 26 seconds

Little Rascal is a virtual pet game made with p5.js. You meet a small creature, care for it, and eventually say goodbye. I wanted a changing relationship, with real consequences: the pet can die if it is neglected. That risk is intended to make care feel like a responsibility and a challenge.

Little Rascal 是我用 p5.js 制作的虚拟宠物游戏。你会认识一只小球，照顾它，最后和它告别。我希望这段关系会变化，照顾也有真实的后果：疏于照顾，宠物可能会死。这种风险是我有意加入的，希望玩家感到责任，也感到挑战。



## 02 — What does a visitor notice first?

Duration: 33 seconds

For an exhibition, I would present it on a computer with a mouse and headphones. That is the proposed setup, not a documented exhibition. The egg gently rocks before the first click. After the arrival animation, the player gives the pet a name. A short guide introduces care. The moving egg invites a first action, but the toy is less obvious: someone could still mistake it for decoration.

如果放在展览里，我会用一台配鼠标和耳机的电脑展示。这是预想的展览设置，不是已经记录过的展览现场。第一次点击之前，蛋会轻轻晃动。出场动画后，玩家给小球起名，再通过简短说明了解照顾方式。晃动的蛋能暗示第一次操作，但玩具球还不够明确：第一次玩的观众可能会以为它只是装饰。

展示形式为拟定方案。当前没有展览现场照片或观众记录。录屏须保留实际点击、拖拽与角色反应。

## 03 — Two minutes inside the room

Duration: 120 seconds

First, I click the egg and give the pet a name. Here, I can feed it, pet it, or throw the toy. Notice that the kick happens when they meet. I have cut between life stages to show the full sequence. In old age, it pauses to rest and asks for affection. After the farewell, the player chooses when to open the letter.

首先，我点击蛋，给它起名。在这里，我可以喂食、摸摸，或者扔出玩具。注意，踢球是在它们碰到时发生的。我剪接了不同成长阶段，方便展示完整流程。到了老年，它会停下来休息，也会表达想被摸摸的需要。告别后，由玩家决定什么时候打开信。

本页预留120秒实际录屏，尚未嵌入视频。英文口播包含在这120秒内，不另加时。00:00–00:25 点击蛋/流星/起名；00:25–00:55 喂食/摸摸/拖球并踢中；00:55–01:20 青年拒绝与状态变化；01:20–02:00 老年休息/气泡/消散/点击信封/新蛋。明确标注“Edited walkthrough · cuts between life stages”。可以剪接你自己录制的画面，不能当作观众测试录像。

## 04 — Why care might become attachment

Duration: 37 seconds

Norman’s framework helps me explain three parts of the experience. The watercolor room and simple face are the first, visceral invitation. At the behavioural level, care has a readable response: a smile, a refusal, or a kick. Reflection comes through the life cycle: birth, growth, aging, farewell and a new egg. The letter recalls one relationship; the next egg invites another. I am aiming for affection and gentle loss, without claiming those emotions have been measured.

诺曼的框架帮助我解释体验的三个部分。水彩房间和简单的脸，构成第一眼的本能吸引。在行为层面，照顾会得到看得懂的回应：微笑、拒绝，或踢球。反思则来自生命循环：出生、成长、衰老、告别，再出现新蛋。感谢信回顾一段关系，新蛋邀请下一次相遇。我希望引起喜爱和温柔的失落，但不声称这些情感已经被测量。

理论：Norman (2004)。本页是基于理论的设计解释，不是测得的玩家情感结果。

## 05 — Four stages became three: a shorter visit

Duration: 38 seconds

I shortened the life cycle from four stages to three to address the time needed for a complete experience. Teenager and adult overlapped, so I combined them into Youth and kept the refusal behaviour there. Childhood now needs three useful feeds and three accepted pettings, then sleep and waking. Youth keeps two useful feeds and two other care actions before waking into old age. The shorter sequence keeps childhood, independence and aging, with one fewer transition to wait through.

为了缩短一次完整体验需要的时间，我已经把四个阶段缩减成了三个。teenager 和 adult 的定位重叠，所以我把它们合并成青年，并把拒绝行为保留在那里。现在幼年需要三次有效喂食、三次接受的摸摸，再睡醒。青年保留两次有效喂食和两次其他照顾，再睡醒进入老年。缩短后的流程仍保留了幼年、独立和衰老，也减少了一次需要等待的过渡。

有效喂食需触发实际照顾计数；幼年玩球、清理不能代替摸摸。计数达标不会即时变形，必须在之后完成睡眠和醒来。青年内部代码键仍为adult。 缩减阶段是作者已经实施的时长优化，不应表述为尚未处理时长。完整流程受照顾速度、睡眠与玩家选择影响，没有统一固定总时长。

## 06 — Play needed a visible point of contact

Duration: 38 seconds

At first, playing was mainly a button. Putting a toy in the room gave the player something to pick up and throw. But my earlier chase looked strange: the pet seemed to follow the ball without touching it. I also found the running too fast. I asked for a slower approach and a small kick at contact. The important change was the sequence: throw, approach, touch, kick. The sound now happens on the kick, rather than when PLAY is selected.

一开始，玩耍主要依靠按钮。把玩具放进房间后，玩家有了可以拿起来、扔出去的东西。但是早期追球很奇怪：宠物像是在隔空跟着球，碰不到它。我还觉得追球太快，于是要求减慢接近速度，碰到时再轻轻踢出去。真正重要的变化是动作顺序：扔出、接近、接触、踢开。现在声音也发生在踢中时，而不是选中 PLAY 的瞬间。

“之前”文字依据本对话中的作者试玩反馈，不是伪造的旧版截图。右侧图片为当前游戏。正式录制建议保留鼠标、球和宠物同框。

## 07 — Youth does not always say yes

Duration: 38 seconds

Youth can refuse feeding, petting or play, with a baseline chance of twenty-five percent. Repeated requests or a full need can produce a still, unimpressed response instead. I wanted it to feel less like a machine that always obeys. However, refusal can also look like a broken control. I revised reactions that lasted too long and kept comfort available when mood is critical. The remaining question is whether a new player reads the refusal as personality or as failure.

青年对喂食、摸摸和玩耍有百分之二十五的基础拒绝概率。重复请求，或者对应数值已满时，也可能让它停在原地，露出无语脸。我不想让它像一台永远服从的机器。不过，拒绝也可能被误认为按钮坏了。我修正了持续过久的反应，并保留心情极低时能被安抚的摸摸。还需要验证的是，新玩家会把拒绝理解为性格，还是操作失败。

基础随机概率不是所有情形的最终拒绝率：满值、重复与危急安抚存在优先级。无语扣3心情，愤怒扣5；不要说拒绝不会影响数值。

## 08 — Older, slower, and more attached

Duration: 38 seconds

Simply slowing the animation looked like playback at half speed. Grounded walking also lost its character. I kept its bounce: three small, slower hops, then about three seconds still. I removed self-initiated ball play, though it still responds to a thrown ball. More importantly, the older pet becomes more attached to the player. It actively asks to be petted through a bubble, three times across senior life. Where Youth sometimes pulls away, Senior asks the player to come closer.

单纯放慢动画，看起来像把视频调成半速。改成贴地走路，也失去了小球的特点。我保留了弹跳：连续三次较小、较慢的跳跃，然后停住约三秒。我删掉了它自己主动玩球的行为，但玩家扔球时它仍然回应。更重要的是，老年的小球变得更依恋玩家。它会通过气泡主动请求摸摸，老年期间出现三次。青年有时会躲开，老年则主动希望玩家靠近。

气泡为漫画框、三个小圈、卡通小手与爱心；不是文字“想摸摸”。睡觉、弹窗、忙碌或危险状态会推迟出现，不能说固定每隔若干秒出现。 作者明确：主动请求摸摸表现老年更依恋玩家，不只是交互提示。属于角色行为设计，不等于观众依恋程度已测量。

## 09 — A body can explain what a bar cannot

Duration: 39 seconds

My tutor suggested adding sound and making needs more visible, including through bubbles. Peer feedback also called for background music, more engaging toy play and richer expressions. I developed the flattened hungry pose below thirty: the bar shows how much is left, while the body shows how hunger feels. The senior bubble asks for affection; not every need has a bubble. I recorded the pet’s voice and selected calls for petting, anger, crying, kicking and idle humming. Crying plays once on entry.

老师建议补充声音，并让状态更直观，比如使用气泡。同学也提出了加入背景音乐、增强玩具互动和丰富表情的建议。我完善了饥饿低于三十时饿扁的状态：数值条显示还剩多少，身体表现饥饿的感觉。老年气泡表达的是想被摸摸，并不是每个需求都有气泡。我录制了小球的声音，选出用于摸摸、生气、哭泣、踢球和自然哼哼的片段。哭声只在进入哭泣时播放一次。

反馈依据：作者在本对话中回忆同学提出背景音乐、增强玩具互动、丰富表情及饿扁状态；老师建议增加音效及状态可视化。属于作者报告的定性反馈，没有参与人数、录音逐字引语或正式研究。作者确认叫声为本人录制。BGM来自Pixabay（按pixaboy理解），音乐按钮只控制BGM。

## 10 — Farewell becomes a new beginning

Duration: 37 seconds

For natural old age, I replaced the abrupt result screen with a slower farewell. The pet pauses, softens and dissolves; its soul rises into stars. A gently moving envelope waits for a click, so the player chooses when to read the letter. Closing it gathers starlight into a new egg. This completes the life cycle: one relationship ends and another can begin. Neglect deaths keep the earlier result screen and restart; they do not receive this thank-you letter.

自然老死的部分，我把突然出现的结算画面改成了缓慢告别。小球停下、身体软下来并消散，灵魂升起化成星星。轻轻晃动的信封等待点击，让玩家决定什么时候读信。关闭信后，星光汇成新的蛋。生命循环由此完成：一段关系结束，另一段可以开始。疏于照顾导致的死亡仍保留原来的结算与重新开始，不会收到这封感谢信。

自然离世通常从进入老年起累计80秒可见活跃时间；忙碌、三次需求气泡等可延后。可剪辑但不可声称完整生命周期只有80秒。感谢信原文不改。

## 11 — What the feedback actually tells me

Duration: 40 seconds

Peer suggestions helped me move beyond a cute character on screen: background music, a toy that feels more interactive, and clearer expressions. My own playthroughs then exposed more specific problems, including disconnected pursuit, slow-motion aging and a rushed hatch. I revised those details, while tutor advice focused my attention on sound and readable needs. These are useful development observations, not a controlled audience study. I can explain what changed, but I cannot yet claim that the final version creates attachment for every player.

同学的建议推动我把作品从屏幕上的可爱角色往前推进：加入背景音乐、让玩具更有互动性、让表情更清楚。自己的反复试玩又暴露出更具体的问题，包括隔空追球、像慢放一样的衰老，以及太快的孵化过程。我修改了这些细节；老师的建议则让我更关注声音和状态是否可读。这些是有用的开发观察，不是受控的受众研究。我能说明改了什么，但还不能声称最终版本会让所有玩家产生依恋。

基于作者报告的同学反馈、自己的试玩及老师意见。不得增添测试人数、姓名、伪造引语或已举办展览的说法。brief还要求给至少一名同学建设性反馈；作者尚未提供这一方向的具体经历，提交前补入真实记录。

## 12 — Consequences are part of caring

Duration: 41 seconds

Death is intentional. If the pet could never die from neglect, keeping it alive would carry less responsibility and challenge. Waste smells after six seconds and can cause illness death at thirteen; hunger or mood at zero for eight seconds can also be fatal. These consequences make attention matter. The question is whether a first-time player can understand the warning and respond fairly. I want to keep the challenge, while testing clearer cues and enough recovery time. Natural old age offers a different kind of ending.

死亡是我有意加入的。如果怎么疏于照顾都不会死，养活它就少了责任感和挑战。粑粑六秒开始发臭，十三秒可能病死；饥饿或心情归零持续八秒也会致死。这些后果让关注和照顾变得重要。需要验证的是，第一次玩的玩家能否理解警告，并有公平的时间回应。我想保留挑战，同时测试更清楚的提示和足够的挽救时间。自然老死则提供了另一种结尾。

作者明确说明死亡用于增加责任感和挑战性，不把死亡本身写成失误。13秒是每个粑粑从产生起的总时长；不是发臭后13秒。公平性属于待验证问题，不声称观众实际感到焦虑。

## 13 — What I would test next

Duration: 37 seconds

The four-to-three-stage change already shortens the visit. Next, I would check whether that revised length works for first-time players, rather than assume it does. Without coaching, do they discover dragging, understand a refusal and respond to warnings? I would compare clearer cues and slightly longer warning periods while keeping the possibility of death. Saved progress and separate voice controls remain future possibilities. The next version should build on the shorter cycle, not add stages back in.

从四阶段缩成三阶段，已经缩短了体验。下一步，我会验证这个调整后的长度是否适合第一次玩的玩家，而不是直接假定它已经合适。在没有指导时，他们会发现拖拽、理解拒绝并回应警告吗？我会比较更清楚的提示和稍长的警告期，同时保留死亡的可能性。存档与独立叫声控制仍是未来方向。下一版应该在缩短后的流程上完善，而不是再加回阶段。

这是未来测试计划，不是已完成研究。若实际补录试玩，请取得参与者同意，并保留具体观察和修改依据。

## 14 — A little life, then another beginning

Duration: 25 seconds

Each stage changes the relationship: the little one needs care, Youth sometimes resists, and Senior asks for closeness. Death gives that care consequences. The new egg completes the cycle of birth, growth, farewell and renewal. I want the player to remember the life they cared for, even as another begins.

每个阶段都在改变这段关系：幼年需要照顾，青年有时拒绝，老年主动寻求陪伴。死亡让照顾有了后果。新的蛋完成了出生、成长、告别和新生的循环。我希望即使新的相遇开始，玩家也会记得自己曾经照顾过的这段生命。

生命循环是设计主题，不声称程序持久保存上一世记忆或名字，也不声称新蛋就是同一只宠物转生。新蛋重新进入既有出场、命名与照顾流程。

## 15 — References & source notes

Duration: 0 seconds





引用采用作者—年份草稿，最终按unit outline规定格式统一。老师已许可AI辅助（作者确认）。叫声为作者本人录制（作者确认）。BGM平台Pixabay（作者原写pixaboy），具体曲名/作者/下载链接待补。参考游戏发布信息仍待核实。

## 16 — AI assistance & submission record

Duration: 0 seconds





作者确认已获老师许可使用AI辅助，叫声音频由本人录制，BGM来源为pixaboy（按Pixabay理解）。声明仍需作者核实实际范围并按课程规定签署；不得把这一确认写成助手独立验证的许可证。音乐曲名、作者及具体链接还未提供。brief要求反思自己给同学的反馈，目前未提供具体例子。

## Submission checks

- 已对照上传的 Assignment Two brief（5页）及rubric（1页），不再依据聊天中的要求摘要。
- 老师多次明确总视频为8–10分钟；第3页另写演示约2分钟、反思约8分钟。因此以总长不超过10分钟为准，约2分钟演示＋7分36秒讲解，按实际语速排练。
- 从功能介绍改为设计反思：展览发现过程、前后对比、修改原因、代价和下一步验证。
- 第一人称内容依据你的实际修改要求整理；个人分析只是编辑草稿，请逐句核实并用自己的话表达，不应让AI代替自己的反思。
- 依据你补充的真实同学建议、老师意见及本人试玩整理；不编造人数、逐字引语、展览经历或观众情绪。
- 这次只更新展示材料，没有改变游戏代码、玩法、数值或美术。
- 已纳入你报告的同学建议。按brief第3页要求，还需要记录你给至少一名同学的具体建设性反馈，并保留真实试玩观察。不要虚构参与人数或引语。
- 你已确认获得老师对AI辅助的许可。brief第2页与第4页仍要求：AI支持而非替代自己的思考，提交时附准确的实际使用声明。请核实声明范围。
- 叫声按你确认标为本人录制；背景音乐按Pixabay标注，补全曲名、作者及原下载链接（你写的是pixaboy，请核对平台拼写）。补全参考游戏信息，区分本人原画与AI辅助迭代素材。
- 录制两分钟真实游戏演示并放入最终视频；当前PPT没有内嵌录像。整段排练在8–10分钟内，不用中英各读一次。
- 使用Curtin标准封面，在Declaration处填写本人姓名作为数字签名；封面模板、姓名与学号未提供，不能代填。
- 写明不失效且公开可访问的视频链接，并附上传时间截图；同时提供清楚标注的工作文件/仓库链接。
- 提交文件名：A2_Surname_GivenName_StudentNumber_FileName。原始brief没有提供具体截止日期，只写Week13，按Blackboard确认。
- 按unit outline规定格式统一引用；这两份PDF没有指定APA/Chicago等具体格式，因此当前使用作者—年份草稿，不冒称完全符合某一种格式。