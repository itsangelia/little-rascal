# Little Rascal — Presentation script

English narration: about 777 words; add a two-minute edited walkthrough.

## 01 — Little Rascal

Time: 22 seconds

Hello. Today I’m presenting Little Rascal, a browser-based virtual pet made with p5.js. The player cares for a small, star-topped character through childhood, youth and old age. My central design question is how everyday interaction can create a sense of attachment.

大家好，今天我介绍的项目是 Little Rascal，一个使用 p5.js 制作的网页虚拟宠物游戏。玩家照顾一只头顶星星的小球，陪它经历幼年、青年和老年。我想探索的核心问题是：日常互动如何建立情感依恋？



## 02 — Can small acts of care create attachment?

Time: 38 seconds

The game asks the player to notice another character’s needs, rather than simply collect points. Hunger, mood and energy create reasons to return to feeding, affection, play and rest. These actions are familiar, but their meaning changes as the pet grows. The intended emotional journey moves from curiosity and affection to responsibility, then farewell. This is a design intention; it has not yet been established through a formal audience study.

游戏希望玩家留意另一个角色的需要，而不只是积累分数。饥饿、心情和能量，让喂食、抚摸、玩耍和休息都有了理由。这些行为很熟悉，但随着宠物成长，它们的意义会改变。我希望玩家从好奇和喜爱，逐步走向责任感，最终经历告别。这是我的设计目标，目前还没有通过正式的受众研究验证。



## 03 — Three layers of connection

Time: 42 seconds

Norman’s three levels of emotional design provide a useful way to discuss the project. At the visceral level, the soft watercolor room and simple face invite attention. At the behavioural level, clear needs and responsive actions help the player understand what to do. At the reflective level, aging and the final letter give those earlier actions a different meaning. These are my applications of the framework, rather than evidence that every player will respond in the same way.

诺曼提出的情感设计三个层次，为讨论这个项目提供了一个框架。在本能层面，柔和的水彩房间和简洁的表情吸引注意力。在行为层面，清晰的需求和及时的反馈帮助玩家理解操作。在反思层面，衰老和最后的感谢信，让之前的照顾产生新的意义。这是我对理论的应用，并不代表每一位玩家都会产生相同的情绪。

Framework source: Norman, D. A. (2004). Emotional Design. Describe this as the designer’s interpretation, not measured audience outcomes.

## 04 — From a first meeting to a new beginning

Time: 38 seconds

The experience begins with a gently moving egg. Clicking it triggers a shooting-star arrival, followed by a naming screen and a short guide. Naming gives the player a personal entry into the relationship. The main loop then combines care with visible feedback. Growth follows useful interactions and the next sleep and waking, rather than a single upgrade button. The final farewell leads back to an egg, so the life cycle can begin again.

体验从一颗轻轻晃动的蛋开始。点击后会出现流星出场动画，接着进入起名和简短说明。起名让玩家更个人化地进入这段关系。主体循环把照顾行为和可见反馈连接起来。成长需要有效互动，并在下一次睡醒后发生，而不是点击一次升级按钮。最后的告别会回到一颗新蛋，让生命循环重新开始。



## 05 — One character, three changing relationships

Time: 39 seconds

The released game has three stages: Little One, Youth and Senior. The youngest stage introduces the care loop. Youth adds independence through refusal and boredom, making the character less predictable. The senior keeps the same recognizable stars and body language, but moves in small hopping bursts with pauses to rest. It also asks for affection through a thought bubble. Changing behaviour, as well as appearance, is what makes the stages feel different.

正式版共有三个阶段：幼年、青年和老年。幼年阶段介绍基础照顾循环。青年阶段通过拒绝和厌烦表现独立性，让角色不那么可预测。老年阶段保留熟悉的星星和身体特征，但改成小幅连续跳动，并停下来休息，还会通过气泡表达想被抚摸的需要。让阶段产生差异的，不只是外形，还有行为。



## 06 — Care is a conversation, not a command

Time: 42 seconds

Youth has a twenty-five percent baseline chance to refuse feeding, petting or play. Repeating an action, or offering something when the corresponding need is already full, can also produce an unimpressed response. The reactions have different body language: angry petting refusal can lead to a quick escape, while boredom keeps the pet still. Refused play can include kicking the ball away. The player must read the response and vary their care, instead of repeating one action indefinitely.

青年阶段对喂食、抚摸和玩耍有百分之二十五的基础拒绝概率。如果连续重复同一操作，或者对应需求已经满了，也可能出现无语表情。不同反应有不同的身体语言：生气地拒绝抚摸时可能快速跳开，厌烦时则原地不动。拒绝玩球时，还可能把球踢走。玩家需要观察反应并调整照顾方式，而不是无限重复一个操作。



## 07 — Bring interaction into the room

Time: 38 seconds

The floor toy makes play a physical action in the room. The player can pick it up and throw it, then watch it bounce and roll. The pet approaches it and kicks only when contact is reached. Other needs also have visible consequences. Low hunger produces a flattened pose, and uncleaned waste develops odor and flies. Together, motion and expression help connect an action, its consequence and the next possible response.

地上的玩具把玩耍变成了房间里的实际动作。玩家可以拿起球再扔出去，观察它弹跳和滚动。宠物靠近后，只有真正碰到球才会踢球。其他需求同样有可见后果：饥饿较低时会出现饿扁的姿态，没及时清理的粑粑会发臭并出现苍蝇。动作和表情共同连接玩家行为、产生的后果，以及下一步可以作出的回应。



## 08 — A life in two minutes

Time: 140 seconds

I’ll now show a two-minute edited walkthrough. It brings together the opening, everyday care, Youth reactions and the senior farewell. Some waiting and repeated care are shortened so the complete life cycle can be shown clearly.

接下来展示一段两分钟的剪辑试玩，串联开场、日常照顾、青年反应以及老年告别。部分等待和重复照顾会缩短，方便清楚展示完整生命周期。

This is a planned 120-second edited gameplay demonstration, not audience-testing evidence. Prepare the actual recording separately. Spoken introduction ≈20 seconds; footage ≈120 seconds. Leave enough screen time to read the envelope/letter; use cuts or clearly marked time compression.

## 09 — Let the player choose when to say goodbye

Time: 40 seconds

Natural old age has a different ending from neglect. The senior pauses, gently softens and dissolves, then a winged soul rises into stars. An envelope appears on the cleared floor. The player chooses when to open it and when to close the thank-you letter. That pause is important to the intended emotional rhythm. Only after closing the letter does starlight gather into a new egg. Neglect deaths retain a separate result screen.

自然老死和照顾不周有不同的结局。老年球球先停下来，身体轻轻瘫软并消散，然后带翅膀的灵魂上升，散成星星。清空的地面上出现信封。玩家自己决定何时打开信封，以及何时关闭感谢信。这个停顿服务于我想设计的情绪节奏。只有关闭信后，星光才会汇聚成新蛋。照顾不周导致的死亡仍然使用独立的结算界面。



## 10 — Build spatial movement with 2D tools

Time: 40 seconds

Technically, the game uses two-dimensional programming with pseudo-three-dimensional movement. Ground position and jump height are calculated separately. Depth scaling, object sorting by floor position and an anchored shadow create the impression of space. Supporting scripts handle hatching, naming, stages, the toy, music and the ending, while the main sketch coordinates gameplay. Background music is enabled by default, but the browser may require the player’s first gesture before allowing playback.

技术上，游戏使用二维编程实现伪三维运动。地面位置和跳跃高度分别计算，再通过远近缩放、按地面位置排序绘制，以及贴地阴影，营造空间感。出场、起名、成长、玩具、音乐和结尾由对应脚本处理，主 sketch 负责协调游戏逻辑。背景音乐默认开启，但浏览器可能需要玩家第一次交互后才允许播放。



## 11 — Make each reaction feel intentional

Time: 42 seconds

Development involved repeated designer-led revisions. Examples include replacing remote-looking toy contact with a contact-timed kick, giving seniors short hops and real rest periods, and simplifying the life cycle to three stages. Browser checks help verify interactions, growth and the ending. They do not establish emotional effectiveness. The next step is to observe actual players and revise from that evidence. Other limitations include fixed canvas dimensions, no saved progress and a need for further accessibility work.

开发过程中进行了多次由设计者主导的调整，例如把看起来隔空互动的玩球改成接触后踢球，让老年宠物有短跳和真正的休息，并把生命周期简化成三个阶段。浏览器检查帮助验证互动、成长和结尾流程，但它们不能证明情感效果。下一步应该观察真实玩家，并根据证据修改。另外，目前仍有固定画布、没有保存进度，以及可访问性尚待完善等限制。



## 12 — A relationship built from small interactions

Time: 24 seconds

Little Rascal brings everyday care, changing personality and a complete life cycle into one small room. Its main contribution is the connection between behaviour and emotional meaning. The next challenge is to test that intention with real players. Thank you for watching.

Little Rascal 把日常照顾、变化的性格和完整生命周期，放进了一个小小的房间。这个项目的重点，是连接行为与情感意义。下一步的挑战是通过真实玩家验证这个设计目标。谢谢观看。

Playable game: https://itsangelia.github.io/little-rascal/?v=b5fe1fc

## 13 — References and production credits

Time: 0 seconds

This appendix records the design framework, technical library and production references. Before submission, confirm the original source and licence for the background music and add the specific reference-game citation required by your course.

附录记录设计框架、技术库和制作参考。提交前，请确认背景音乐原始来源和使用许可，并按课程要求补全参考游戏的具体引用。

Credits must distinguish uploaded original illustrations from generated design explorations. Do not claim all assets are exclusively hand-drawn by the student. Confirm instructor requirements for AI disclosure. No formal audience study or participant metrics are claimed.
