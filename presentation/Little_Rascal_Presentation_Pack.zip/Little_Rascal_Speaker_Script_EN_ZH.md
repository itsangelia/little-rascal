# Little Rascal — Presentation script

English narration: about 808 words; add a two-minute edited walkthrough.

## 01 — Little Rascal

Time: 22 seconds

Hello. Today I’m presenting Little Rascal, a browser-based virtual pet made with p5.js. The player cares for a small, star-topped character through childhood, youth and old age. My central design question is how everyday interaction can create a sense of attachment.

大家好，今天我介绍的项目是 Little Rascal，一个使用 p5.js 制作的网页虚拟宠物游戏。玩家照顾一只头顶星星的小球，陪它经历幼年、青年和老年。我想探索的核心问题是：日常互动如何建立情感依恋？



## 02 — Can small acts of care create attachment?

Time: 38 seconds

The game asks the player to notice another character’s needs, rather than simply collect points. Hunger, mood and energy create reasons to return to feeding, affection, play and rest. These actions are familiar, but their meaning changes as the pet grows. The intended emotional journey moves from curiosity and affection to responsibility, then farewell. This is a design intention; it has not yet been established through a formal audience study.

游戏希望玩家留意另一个角色的需要，而不只是积累分数。饥饿、心情和能量，让喂食、抚摸、玩耍和休息都有了理由。这些行为很熟悉，但随着宠物成长，它们的意义会改变。我希望玩家从好奇和喜爱，逐步走向责任感，最终经历告别。这是我的设计目标，目前还没有通过正式的受众研究验证。



## 03 — Three layers of connection

Time: 42 seconds

Norman’s three levels of emotional design provide a useful way to discuss the project. At the visceral level, the soft watercolor room and simple face invite attention. At the behavioural level, clear needs and responsive actions help the player understand what to do. At the reflective level, aging and the final letter give those earlier actions a different meaning. These are my applications of the framework, rather than evidence that every player will respond in the same way.

诺曼提出的情感设计三个层次，为讨论这个项目提供了一个框架。在本能层面，柔和的水彩房间和简洁的表情吸引注意力。在行为层面，清晰的需求和及时的反馈帮助玩家理解操作。在反思层面，衰老和最后的感谢信，让之前的照顾产生新的意义。这是我对理论的应用，并不代表每一位玩家都会产生相同的情绪。

Framework source: Norman, D. A. (2004). Emotional Design. Describe this as the designer’s interpretation, not measured audience outcomes.

## 04 — From a first meeting to a new beginning

Time: 44 seconds

The experience begins with a gently moving egg. Clicking it triggers a shooting-star arrival, naming and a short guide. Naming gives the player a personal entry into the relationship. Childhood growth now requires three effective feeds and three petting actions, followed by the next sleep and waking. Below thirty energy, the little one automatically goes to bed. Sleep remains visible for at least three seconds and restores energy before waking. The final farewell leads back to an egg, so the life cycle can begin again.

体验从一颗轻轻晃动的蛋开始。点击后出现流星出场、起名和简短说明。起名让玩家更个人化地进入这段关系。现在，幼儿期需要累计三次有效喂食和三次摸摸，再在下一次睡醒后长大。能量低于三十时，幼儿会自动去睡觉。睡眠至少有三秒可见过程，并恢复能量后醒来。最后的告别会回到新蛋，开始下一轮生命。

Child → Youth: 3 effective feeds (hunger ≤95, available for care) +3 accepted PET actions, then next completed sleep. PLAY, toy rewards and CLEAN do not replace childhood PET. Youth → Senior retains2 effective feeds+2 other care actions. Child auto-sleeps strictly below30 energy after current care/play; other stages retain≤8. At least3 visible seconds asleep AND energy≥80 to wake. Never show growth before waking.

## 05 — One character, three changing relationships

Time: 39 seconds

The released game has three stages: Little One, Youth and Senior. Childhood is more vocal, with occasional spontaneous humming during eligible idle time. Its feeding, petting and rest introduce responsibility. Youth adds independence through refusal and boredom. The senior keeps the recognizable stars, but moves in small hopping bursts with pauses to rest and asks for affection through a thought bubble. Changing behaviour and sound, as well as appearance, make the stages feel different.

正式版共有幼年、青年和老年三个阶段。幼儿期会在空闲时偶尔自然哼哼，喂食、摸摸和休息让玩家建立照顾的责任感。青年通过拒绝和厌烦表现独立性。老年保留熟悉的星星外形，但以短跳和停顿表现衰老，并通过气泡请求抚摸。阶段差异来自行为、声音与外形的共同变化。

Child humL:7–10 eligible idle seconds; Youth/Senior:10–18. Busy actions, distress, sleep, dialogs and hidden tabs pause/suppress humming. Childhood waste:24–36s ordinary scheduling;8–12s after meals. Other stages:18–30s /5–8.5s. Existing illness deadlines remain6s flies,13s fatal.

## 06 — Care is a conversation, not a command

Time: 42 seconds

Youth has a twenty-five percent baseline chance to refuse feeding, petting or play. Repeating an action, or offering something when the corresponding need is already full, can also produce an unimpressed response. The reactions have different body language: angry petting refusal can lead to a quick escape, while boredom keeps the pet still. Refused play can include kicking the ball away. The player must read the response and vary their care, instead of repeating one action indefinitely.

青年阶段对喂食、抚摸和玩耍有百分之二十五的基础拒绝概率。如果连续重复同一操作，或者对应需求已经满了，也可能出现无语表情。不同反应有不同的身体语言：生气地拒绝抚摸时可能快速跳开，厌烦时则原地不动。拒绝玩球时，还可能把球踢走。玩家需要观察反应并调整照顾方式，而不是无限重复一个操作。



## 07 — Let the pet show and voice its needs

Time: 38 seconds

The floor toy makes play physical. The player throws it, and the pet kicks only after contact. A short call follows the kick, making the timing clearer. Other recorded sounds distinguish accepted petting, anger and spontaneous humming. A crying cue plays once when crying begins, without looping. Hunger below thirty also changes the body into a flattened pose. This already visualizes a need beyond a bar. Expression, movement and sound work together to help the player understand the pet.

地上的玩具让玩耍成为实际动作。玩家扔出球，宠物只有碰到球才会踢，踢中时的短叫声让反馈更清楚。其他原声分别用于接受摸摸、生气和自然哼哼。哭声只在开始哭泣时播放一次，不会在持续哭泣时循环。饥饿低于三十还会切换成饿扁形态，这已经是数值条之外的需求可视化。表情、动作与声音共同帮助玩家理解宠物。

Owner-approved audio: C accepted PET; B anger; A crying onset once per visible episode; D actual friendly toy-contact kick only; L spontaneous humming. Reusable native HTMLAudio playback preserves original pitch/speed. Speaker toggles BGM ONLY; pet effects remain enabled. Calls reduce BGM briefly and restore prior volume. Generic hunger/energy bubbles are not implemented; existing senior affection bubble remains.

## 08 — A life in two minutes

Time: 140 seconds

I’ll now show a two-minute edited walkthrough. It brings together the opening, everyday care, Youth reactions and the senior farewell. Some waiting and repeated care are shortened so the complete life cycle can be shown clearly.

接下来展示一段两分钟的剪辑试玩，串联开场、日常照顾、青年反应以及老年告别。部分等待和重复照顾会缩短，方便清楚展示完整生命周期。

This is a planned 120-second edited gameplay demonstration, not audience-testing evidence. Prepare the actual recording separately. Spoken introduction ≈20 seconds; footage ≈120 seconds. Leave enough screen time to read the envelope/letter; use cuts or clearly marked time compression. Record current audio: C on accepted PET, D at contact, B on Youth anger; include one brief A crying onset and one L idle hum where possible. Show child3feed+3PET readiness and sleep/wake through clearly edited clips. The full life cycle is not claimed to fit uncut into120seconds.

## 09 — Let the player choose when to say goodbye

Time: 40 seconds

Natural old age has a different ending from neglect. The senior pauses, gently softens and dissolves, then a winged soul rises into stars. An envelope appears on the cleared floor. The player chooses when to open it and when to close the thank-you letter. That pause is important to the intended emotional rhythm. Only after closing the letter does starlight gather into a new egg. Neglect deaths retain a separate result screen.

自然老死和照顾不周有不同的结局。老年球球先停下来，身体轻轻瘫软并消散，然后带翅膀的灵魂上升，散成星星。清空的地面上出现信封。玩家自己决定何时打开信封，以及何时关闭感谢信。这个停顿服务于我想设计的情绪节奏。只有关闭信后，星光才会汇聚成新蛋。照顾不周导致的死亡仍然使用独立的结算界面。



## 10 — Build spatial movement with 2D tools

Time: 43 seconds

The game uses two-dimensional programming with pseudo-three-dimensional movement. Ground position and jump height are separate; depth scaling, Y sorting and shadows create space. Internal coordinates remain nine hundred by six hundred and forty, with CSS window fitting and player-triggered fullscreen. Sound uses reusable native audio players, matching the audition page. Recorded clips retain their original pitch and speed. The speaker controls background music only, while pet calls remain audible. Browser gesture handling and playback checks support reliable interaction.

游戏使用二维编程实现伪三维运动。地面位置与跳跃高度分开计算，再用远近缩放、按地面位置排序和阴影营造空间。内部坐标保持九百乘六百四十，通过 CSS 适配窗口，并由玩家主动点击全屏。声音改用与试听页相同的原生音频播放器，保留原声的音调与速度。扬声器只控制背景音乐，宠物叫声继续保留。手势启动处理与播放检查帮助保障互动反馈。

Release d3ab74f. Main scripts: sketch.js care/growth/child sleep; sound-effects.js reusable HTMLAudio, silent gesture warmups, priority and one-shot cues; music.js BGM-only toggle. Native FX volume.9, idle65% relative; BGM briefly ducks to≤.135 then restores without toggling/starting music. p5.sound add-ons are no longer required. Fixed internal coordinates and native input/fullscreen alignment preserved.

## 11 — Make each reaction feel intentional

Time: 42 seconds

Designer-led iteration improved contact-timed kicks, senior hops and rest, the watercolor interface, and the three-stage life cycle. Recent changes make childhood growth depend on three feeds and three petting actions, followed by waking, and trigger automatic sleep below thirty energy. Sound was also revised: native playback and mixing checks replaced a fragile audio path. Browser checks verify these behaviours, but do not establish emotional effectiveness. Real audience feedback, saved progress and accessibility remain future work.

设计者主导的迭代改进了接触后踢球、老年的跳动与休息、水彩界面和三阶段生命周期。最近把幼儿成长改为三次有效喂食加三次摸摸后睡醒，并加入能量低于三十的自动睡眠。音频也经过调整：改用原生播放，并检查与背景音乐同时播放时的表现。浏览器检查验证行为，但不能证明情感效果。真实受众反馈、进度保存和可访问性仍是未来方向。

Implemented: childhood3feed+3PET then waking, auto-bed<30, hum7–10eligible seconds, ordinary waste24–36s and meal8–12s; owner-selected C/B/A/D/L audio; native playback checked with BGM active, not only with music muted. No formal audience study or measured emotional-effectiveness claims. Keep prior fixed-canvas/CSS adaptation explanation accurate.

## 12 — A relationship built from small interactions

Time: 24 seconds

Little Rascal brings everyday care, changing personality and a complete life cycle into one small room. Its main contribution is the connection between behaviour and emotional meaning. The next challenge is to test that intention with real players. Thank you for watching.

Little Rascal 把日常照顾、变化的性格和完整生命周期，放进了一个小小的房间。这个项目的重点，是连接行为与情感意义。下一步的挑战是通过真实玩家验证这个设计目标。谢谢观看。

Playable game: https://itsangelia.github.io/little-rascal/?v=d3ab74f

## 13 — References and production credits

Time: 0 seconds

This appendix records the design framework, technical library and production references. Before submission, confirm source and licence credits for the background music and uploaded voice recording, and complete the reference-game citation required by the course.

附录记录设计框架、技术库和制作参考。提交前请确认背景音乐与上传叫声音频的来源、使用许可，并按课程要求补全参考游戏引用。

Credits must distinguish uploaded original illustrations from generated design explorations. Do not claim all assets are exclusively hand-drawn by the student. Confirm instructor requirements for AI disclosure. No formal audience study or participant metrics are claimed. Pet calls are edited excerpts from the owner-uploaded 提取的音频.m4a, not generated voices. Do not label them as self-recorded or royalty-free without verification.
